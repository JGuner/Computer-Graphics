import math

class Light:
    def __init__(self, v, r, g, b):
        self.v = v
        self.r = r
        self.g = g
        self.b = b

class Surface:
    def __init__(self, dr, dg, db):
        self.dr = dr
        self.dg = dg
        self.db = db

class Ray():
    def __init__(self, origin, direction):
        self.origin = origin
        self.direction = direction

    def getXYZ(self, t):
        x = self.origin.x + (t * self.direction.x)
        y = self.origin.y + (t * self.direction.y)
        z = self.origin.z + (t * self.direction.z)
        return PVector(x, y, z)
    
class Sphere:
    def __init__(self, radius, v, r, g, b):
        self.radius = radius
        self.center = v
        self.r = r
        self.g = g
        self.b = b

    def getIntersect(self, ray):
        toSphere = ray.origin - self.center
        point1 = ray.direction.dot(ray.direction)
        point2 = 2 * (toSphere.dot(ray.direction))
        point3 = toSphere.dot(toSphere) - (self.radius **2)

        discriminant = (point2*point2) - (4*point1*point3)
        #print(discriminant)
        if discriminant < 0:
            return None
        else: 
            hits = (-point2 - sqrt(discriminant)) / (2*point1)
            return ray.getXYZ(hits)
